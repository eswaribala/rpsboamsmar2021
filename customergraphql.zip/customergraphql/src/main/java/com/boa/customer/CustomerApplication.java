package com.boa.customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

/*import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.vault.config.SecretBackendConfigurer;
import org.springframework.cloud.vault.config.VaultConfigurer;
import org.springframework.context.annotation.Bean;*/
/*
 * mutation{
  createCustomer(firstName:"x",lastName:"y",emailId:"pra@gmail.com",mobileNo:73624723,dob: "1986-12-04",gender:"MALE")
  {
     customerId
  }
}
query{
  findCustomer(customerId:1){
    name
    
  }
}
http://localhost:7070/graphql/schema.json
http://localhost:7070/graphql?query=%7BfindAllCustomers%7BcustomerId%7D%7D
http://localhost:7070/graphql?query=%7BfindAllCustomers%7BcustomerId%20name%7D%7D
 */

//@RefreshScope
@SpringBootApplication
@EnableAutoConfiguration(exclude =DataSourceAutoConfiguration.class)
//@EnableEurekaClient
public class CustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerApplication.class, args);
	}
	@Bean
	public RestTemplate getRestTemplate()
	{
		return new RestTemplate();
	}
}
