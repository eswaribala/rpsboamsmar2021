package com.boa.customer.models;

public enum GenderType {
MALE,FEMALE,TRANSGENDER
}
